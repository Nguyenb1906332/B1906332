<!DOCTYPE HTML>
<html>  
<body>

<form action="checkmk.php" method="post">
Mat khau cu: <input type="password" name="pass"><br>
Mat khau moi: <input type="password" name="newpass"><br>
Xac nhan lai MK: <input type="password" name="newpass"><br>

<input type="submit">

</form>

</body>
</html>
